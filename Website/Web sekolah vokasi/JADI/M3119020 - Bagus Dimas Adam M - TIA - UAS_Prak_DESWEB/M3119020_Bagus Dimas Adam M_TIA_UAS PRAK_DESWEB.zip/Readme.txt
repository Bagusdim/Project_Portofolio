 Asslamaualaikum Wr. Wb.
  
  Berikut Merupakan tata cara mengakses webnya:
      1.Buka file dengan nama index.html
      2.Karena web tidak mengunakan hosting dan domain dapat diakses secara offline.
        - Namun jika ingin mengakses sosial media perlu konektifitas internet.
      3.Karena web menggunakan ukuran px maka harus disesuaikan sendiri dengan layout masing-masing.
      4.Setiap Link konten dapat diakses secara offline.
      5.Untuk Menghilangkan gambar slider tekan tombol kiri atau kembali pada gambar pertama.
      - Untuk Menampilkanya kembali dengan cara me refresh web.
      6. Background berganti apabila berganti bulan pada kalender. 

Walaikumsalam Wr. Wb.

DESIGN 
BY BAGUS DIMAS ADAM M

Happy enjoy with this web :)

