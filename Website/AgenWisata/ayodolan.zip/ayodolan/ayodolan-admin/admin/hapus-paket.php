<html>
<body> 
    <?php
    $idDetail_paket = $_GET ['id'];
    require('config.php');
    $sql1 = "DELETE FROM paket_wisata WHERE idDetail_paket = '$idDetail_paket'";
    $sql2 = "DELETE FROM detail_paket WHERE idDetail_paket = '$idDetail_paket'";
if ($conn->query($sql1) && $conn->query($sql2) === TRUE) {
    echo "Data berhasil dihapus. Kembali ke halaman sebelumnya";
    header("refresh:3;daftar-paket.php");
  } else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
    echo "Error: " . $sql2 . "<br>" . $conn->error;
  }
  $conn->close();
    ?>
</body>
</html>