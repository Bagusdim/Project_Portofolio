<html>
<body> 
    <?php 
    require('config.php');
    $id_paket = $_POST ['id_paket'];
    $idDetail_paket = $_POST ['idDetail_paket'];
    $lokasi = $_POST ['lokasi'];
    $durasi = $_POST ['durasi'];
    $kota = $_POST ['kota'];
    $provinsi = $_POST ['provinsi'];
    $fasilitas = $_POST ['fasilitas'];
    $harga = $_POST ['harga'];

    if ($id_paket == "") {
      header("location:tambah-paket.php?id_paket=id_paketkosong");
    } else {
      if (!preg_match("/^[A-Z]{4}[0-9]{4}/",$id_paket)) {
        header("location:tambah-paket.php?id_paket=id_paketErr");
      }
    }

    if ($idDetail_paket == "") {
        header("location:tambah-paket.php?idDetail_paket=idDetail_paketkosong");
      } else {
        if (!preg_match("/^[A-Z]{3}[0-9]{3}/",$idDetail_paket)) {
          header("location:tambah-paket.php?idDetail_paket=idDetail_paketErr");
        }
    }

    if ($lokasi == "") {
      header("location:tambah-paket.php?lokasi=lokasikosong");
    }

    if ($durasi == "") {
      header("location:tambah-paket.php?durasi=durasikosong");
    }

    if ($kota == "") {
      header("location:tambah-paket.php?kota=kotakosong");
    }

    if ($provinsi == "") {
      header("location:tambah-paket.php?provinsi=provinsikosong");
    }

    if ($fasilitas == "") {
      header("location:tambah-paket.php?fasilitas=fasilitaskosong");
    }

    if ($harga == "") {
      header("location:tambah-paket.php?harga=hargakosong");
    }
    
    if (!$id_paket == "" && preg_match("/^[A-Z]{4}[0-9]{4}/",$id_paket) && !$idDetail_paket == "" && preg_match("/^[A-Z]{3}[0-9]{3}/",$idDetail_paket) && !$lokasi == "" && !$durasi == "" && !$kota == "" && !$provinsi == "" && !$fasilitas == "" && !$harga == "") {
      $sql1 = "INSERT INTO detail_paket(idDetail_paket, lokasi, durasi, kota, provinsi, fasilitas)
      VALUES ('$idDetail_paket', '$lokasi', '$durasi', '$kota', '$provinsi', '$fasilitas')";

      $sql2 = "INSERT INTO paket_wisata(id_paket, idDetail_paket, harga_paket)
      VALUES ('$id_paket', '$idDetail_paket', '$harga')";
    }

    if ($conn->query($sql1) && $conn->query($sql2) === TRUE) {
      echo "Data berhasil ditambahkan. Kembali ke daftar paket";
      header("refresh:3;daftar-paket.php");
    } else {
      echo "Error: " . $sql1 . "<br>" . $conn->error;
      echo "Error: " . $sql2 . "<br>" . $conn->error;
    }

    $conn->close();
    ?>
</body>
</html>