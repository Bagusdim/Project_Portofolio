<html>
<body> 
    <?php
    $id_paket = $_GET ['id'];
    require('config.php');
    $sql1 = "DELETE FROM pemesanan WHERE id_paket = '$id_paket'";
    $sql2 = "DELETE FROM pembayaran WHERE id_paket = '$id_paket'";
    $sql3 = "DELETE FROM paket_wisata WHERE id_paket = '$id_paket'";
    $sql4 = "DELETE FROM detail_paket WHERE id_paket = '$id_paket'";
if ($conn->query($sql1) && $conn->query($sql2) && $conn->query($sql3) && $conn->query($sql4) === TRUE) {
    echo "Data berhasil dihapus. Kembali ke halaman sebelumnya";
    header("refresh:3;index.php");
  } else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
    echo "Error: " . $sql2 . "<br>" . $conn->error;
    echo "Error: " . $sql3 . "<br>" . $conn->error;
    echo "Error: " . $sql4 . "<br>" . $conn->error;
  }
  $conn->close();
    ?>
</body>
</html>