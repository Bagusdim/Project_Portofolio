<html>
<body> 
    <?php
    $tanggalberangkat = $_POST ['tanggalberangkat'];
    $tanggalkepulangan = $_POST ['tanggalkepulangan'];
    $jumlahorang = $_POST ['jumlahorang'];
    $tanggalbayar = $_POST ['tanggalbayar'];
    $status = $_POST ['status'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "agenwisata";
    $conn = new mysqli($servername, $username, $password, $dbname);

      if ($tanggalberangkat == "") {
        echo "<h4 style='color:red'>Tanggal Berangkat harus diisi!</h4>";
        header("refresh:3;index.php");
      }
  
      if ($tanggalkepulangan == "") {
        echo "<h4 style='color:red'>Tanggal Kepulangan harus diisi!</h4>";
        header("refresh:3;index.php");
      }
  
      if ($jumlahorang == "") {
        echo "<h4 style='color:red'>Jumlah Orang harus diisi!</h4>";
        header("refresh:3;index.php");
      }
  
      if ($tanggalbayar == "") {
        echo "<h4 style='color:red'>Tanggal Bayar harus diisi!</h4>";
        header("refresh:3;index.php");
      }
  
      if ($status == "") {
        echo "<h4 style='color:red'>Status harus diisi!</h4>";
        header("refresh:3;index.php");
      }

    if (!$tanggalberangkat == "" && !$tanggalkepulangan == "" && !$jumlahorang == "" && !$tanggalbayar == "" && !$status == "") {
        $sql1 = "UPDATE pemesanan SET tgl_mulai = '$tanggalberangkat', tgl_selesai = '$tanggalkepulangan', jumlah_orang = '$jumlahorang' WHERE tgl_mulai = '$tanggalberangkat'";
      
        $sql2 = "UPDATE pembayaran SET tanggal_pembayaran = '$tanggalbayar', status = '$status' WHERE tanggal_pembayaran = '$tanggalbayar'";
    }
    
    
if ($conn->query($sql1) && $conn->query($sql2) === TRUE) {
    echo "Data berhasil diubah. Kembali ke halaman sebelumnya";
    header("refresh:3;index.php");
  } else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
    echo "Error: " . $sql2 . "<br>" . $conn->error;
  }
  $conn->close();
    ?>
</body>
</html>