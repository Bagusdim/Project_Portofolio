<html>
<body> 
    <?php
    session_start();
    require('config.php');
    $tujuan = $_POST ['tujuan'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "agenwisata";
    $conn = new mysqli($servername, $username, $password, $dbname);    

    $sql1 = "INSERT INTO pemesanan(id_pemesanan)
    VALUES ('')";
    
    $sql2 = "INSERT INTO pembayaran(id_pemesanan)
    VALUES ('')";
    
    
    if ($conn->query($sql1) && $conn->query($sql2) === TRUE) {
      echo "Pesanan berhasil ditambahkan !";
      header("refresh:3;riwayat-perjalanan.php");
    } else {
      echo "Error: " . $sql1 . "<br>" . $conn->error;
      echo "Error: " . $sql2 . "<br>" . $conn->error;
    }
  $conn->close();
    ?>
</body>
</html>