<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="AYODOLAN.ID">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>AYODOLAN - Agen Wisata Terbaik se-Solo Raya</title>
    <link rel="stylesheet" href="css/nicepage.css" media="screen">
    <link rel="stylesheet" href="css/Homepage.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.1.3, nicepage.com">
    <link rel="icon" href="images/favicon.png">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "AYODOLAN",
		"url": "index.php",
		"logo": "images/11901401-0.png",
		"sameAs": [
				"#",
				"#",
				"#"
		]
}</script>
    <meta property="og:title" content="Homepage">
    <meta property="og:type" content="website">
    <meta name="theme-color" content="#478ac9">
    <link rel="canonical" href="index.php">
    <meta property="og:url" content="index.php">
  </head>
  <body class="u-body"><header class="u-align-center-sm u-align-center-xs u-clearfix u-header u-header" id="sec-941d"><div class="u-clearfix u-sheet u-sheet-1">
        <?php session_start(); ?>
        <a href="index.php" data-page-id="11901401" class="u-image u-logo u-image-1" data-image-width="150" data-image-height="150" title="Homepage">
          <img src="images/11901401-0.png" class="u-logo-image u-logo-image-1" data-image-width="63">
        </a>
        <div class="u-social-icons u-spacing-10 u-social-icons-1">
          <a class="u-social-url" target="_blank" href="#"><span class="u-icon u-icon-circle u-social-facebook u-social-type-logo u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-1bdd"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-1bdd"><path d="M75.5,28.8H65.4c-1.5,0-4,0.9-4,4.3v9.4h13.9l-1.5,15.8H61.4v45.1H42.8V58.3h-8.8V42.4h8.8V32.2 c0-7.4,3.4-18.8,18.8-18.8h13.8v15.4H75.5z"></path></svg></span>
          </a>
          <a class="u-social-url" target="_blank" href="#"><span class="u-icon u-icon-circle u-social-twitter u-social-type-logo u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-da0f"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-da0f"><path d="M92.2,38.2c0,0.8,0,1.6,0,2.3c0,24.3-18.6,52.4-52.6,52.4c-10.6,0.1-20.2-2.9-28.5-8.2 c1.4,0.2,2.9,0.2,4.4,0.2c8.7,0,16.7-2.9,23-7.9c-8.1-0.2-14.9-5.5-17.3-12.8c1.1,0.2,2.4,0.2,3.4,0.2c1.6,0,3.3-0.2,4.8-0.7 c-8.4-1.6-14.9-9.2-14.9-18c0-0.2,0-0.2,0-0.2c2.5,1.4,5.4,2.2,8.4,2.3c-5-3.3-8.3-8.9-8.3-15.4c0-3.4,1-6.5,2.5-9.2 c9.1,11.1,22.7,18.5,38,19.2c-0.2-1.4-0.4-2.8-0.4-4.3c0.1-10,8.3-18.2,18.5-18.2c5.4,0,10.1,2.2,13.5,5.7c4.3-0.8,8.1-2.3,11.7-4.5 c-1.4,4.3-4.3,7.9-8.1,10.1c3.7-0.4,7.3-1.4,10.6-2.9C98.9,32.3,95.7,35.5,92.2,38.2z"></path></svg></span>
          </a>
          <a class="u-social-url" target="_blank" href="#"><span class="u-icon u-icon-circle u-social-instagram u-social-type-logo u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-7368"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-7368"><path d="M55.9,32.9c-12.8,0-23.2,10.4-23.2,23.2s10.4,23.2,23.2,23.2s23.2-10.4,23.2-23.2S68.7,32.9,55.9,32.9z M55.9,69.4c-7.4,0-13.3-6-13.3-13.3c-0.1-7.4,6-13.3,13.3-13.3s13.3,6,13.3,13.3C69.3,63.5,63.3,69.4,55.9,69.4z"></path><path d="M79.7,26.8c-3,0-5.4,2.5-5.4,5.4s2.5,5.4,5.4,5.4c3,0,5.4-2.5,5.4-5.4S82.7,26.8,79.7,26.8z"></path><path d="M78.2,11H33.5C21,11,10.8,21.3,10.8,33.7v44.7c0,12.6,10.2,22.8,22.7,22.8h44.7c12.6,0,22.7-10.2,22.7-22.7 V33.7C100.8,21.1,90.6,11,78.2,11z M91,78.4c0,7.1-5.8,12.8-12.8,12.8H33.5c-7.1,0-12.8-5.8-12.8-12.8V33.7 c0-7.1,5.8-12.8,12.8-12.8h44.7c7.1,0,12.8,5.8,12.8,12.8V78.4z"></path></svg></span>
          </a>
        </div>

        <!-- Navbar Menu -->
        <?php
          include('menu.php');
        ?>
        <!-- /Navbar Menu -->

        <h1 class="u-text u-text-custom-color-1 u-text-default u-title u-text-1">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-custom-color-1 u-btn-1" href="index.php" data-page-id="11901401">AYODOLAN.COM</a>
        </h1>
      </div></header>
    <section class="u-align-center u-clearfix u-section-1" id="carousel_e116">
      <img src="images/GettyImages-1063767512.jpg" class="u-align-left u-expanded-width u-image u-left-0 u-image-1" data-image-width="701" data-image-height="394">
      <div class="u-clearfix u-gutter-30 u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-container-style u-layout-cell u-left-cell u-palette-1-base u-size-20 u-layout-cell-1">
              <div class="u-container-layout u-valign-top u-container-layout-1"><span class="u-icon u-icon-circle u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 55.017 55.017"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-3949"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 55.017 55.017" x="0px" y="0px" id="svg-3949" style="enable-background:new 0 0 55.017 55.017;"><g><path d="M51.688,23.013H40.789c-0.553,0-1,0.447-1,1s0.447,1,1,1h9.102l2.899,27H2.268l3.403-27h9.118c0.553,0,1-0.447,1-1
		s-0.447-1-1-1H3.907L0,54.013h55.017L51.688,23.013z"></path><path d="M26.654,38.968c-0.147,0.087-0.304,0.164-0.445,0.255c-0.22,0.142-0.435,0.291-0.646,0.445
		c-0.445,0.327-0.541,0.953-0.215,1.398c0.196,0.267,0.5,0.408,0.808,0.408c0.205,0,0.412-0.063,0.591-0.193
		c0.178-0.131,0.359-0.257,0.548-0.379c0.321-0.208,0.662-0.403,1.014-0.581c0.468-0.237,0.658-0.791,0.462-1.269
		c0.008-0.008,0.018-0.014,0.025-0.022c1.809-1.916,7.905-9.096,10.429-21.058c0.512-2.426,0.627-4.754,0.342-6.919
		c-0.86-6.575-4.945-10.051-11.813-10.051c-6.866,0-10.951,3.476-11.813,10.051c-0.284,2.166-0.169,4.494,0.343,6.919
		C18.783,29.818,24.783,36.97,26.654,38.968z M17.924,11.314c0.733-5.592,3.949-8.311,9.831-8.311c5.883,0,9.098,2.719,9.83,8.311
		c0.255,1.94,0.148,4.043-0.316,6.247C35,28.314,29.59,35.137,27.755,37.207c-1.837-2.072-7.246-8.898-9.514-19.646
		C17.776,15.357,17.67,13.255,17.924,11.314z"></path><path d="M27.755,19.925c4.051,0,7.346-3.295,7.346-7.346s-3.295-7.346-7.346-7.346s-7.346,3.295-7.346,7.346
		S23.704,19.925,27.755,19.925z M27.755,7.234c2.947,0,5.346,2.398,5.346,5.346s-2.398,5.346-5.346,5.346s-5.346-2.398-5.346-5.346
		S24.808,7.234,27.755,7.234z"></path><path d="M31.428,37.17c-0.54,0.114-0.884,0.646-0.769,1.187c0.1,0.47,0.515,0.791,0.977,0.791c0.069,0,0.14-0.007,0.21-0.022
		c0.586-0.124,1.221-0.229,1.886-0.313c0.548-0.067,0.938-0.567,0.869-1.115c-0.068-0.549-0.563-0.945-1.115-0.869
		C32.763,36.918,32.07,37.033,31.428,37.17z"></path><path d="M36.599,37.576c0.022,0.537,0.466,0.957,0.998,0.957c0.015,0,0.029,0,0.044-0.001l2.001-0.083
		c0.551-0.025,0.979-0.493,0.953-1.044c-0.025-0.553-0.539-0.984-1.044-0.954l-1.996,0.083
		C37.003,36.557,36.575,37.023,36.599,37.576z"></path><path d="M22.433,42.177c-0.514,0.388-1.045,0.761-1.58,1.107c-0.463,0.301-0.595,0.92-0.294,1.384
		c0.191,0.295,0.513,0.455,0.84,0.455c0.187,0,0.375-0.052,0.544-0.161c0.573-0.372,1.144-0.772,1.695-1.188
		c0.44-0.333,0.528-0.96,0.196-1.401C23.501,41.936,22.876,41.844,22.433,42.177z"></path><path d="M44.72,35.583c-0.338,0.237-0.777,0.409-1.346,0.526c-0.541,0.111-0.889,0.641-0.777,1.182
		c0.098,0.473,0.514,0.798,0.979,0.798c0.067,0,0.135-0.007,0.203-0.021c0.842-0.174,1.526-0.452,2.096-0.853l0.134-0.098
		c0.44-0.334,0.527-0.961,0.194-1.401c-0.334-0.44-0.96-0.526-1.401-0.194L44.72,35.583z"></path><path d="M8.86,43.402c0.145-0.533-0.171-1.082-0.704-1.226c-0.529-0.149-1.082,0.169-1.226,0.704
		c-0.126,0.464-0.201,0.938-0.225,1.405C6.7,44.4,6.697,44.516,6.697,44.638c0.001,0.196,0.01,0.392,0.029,0.587
		c0.053,0.515,0.487,0.898,0.994,0.898c0.033,0,0.067-0.002,0.103-0.005c0.549-0.057,0.949-0.547,0.894-1.097
		c-0.014-0.131-0.019-0.264-0.02-0.39c0-0.083,0.003-0.166,0.007-0.248C8.72,44.059,8.772,43.728,8.86,43.402z"></path><path d="M44.698,27.81c-0.794-0.106-1.604-0.041-2.386,0.181c-0.532,0.149-0.841,0.702-0.69,1.233
		c0.124,0.441,0.525,0.729,0.961,0.729c0.091,0,0.182-0.012,0.272-0.038c0.52-0.146,1.055-0.192,1.575-0.122
		c0.562,0.07,1.052-0.311,1.125-0.857C45.629,28.387,45.245,27.884,44.698,27.81z"></path><path d="M46.688,32.764c-0.163,0.527,0.133,1.088,0.66,1.25c0.099,0.031,0.197,0.045,0.295,0.045c0.428,0,0.823-0.275,0.955-0.705
		c0.099-0.318,0.16-0.641,0.183-0.963c0.005-0.083,0.008-0.167,0.008-0.25c0-0.468-0.086-0.937-0.255-1.392
		c-0.192-0.519-0.771-0.781-1.285-0.59c-0.519,0.192-0.782,0.768-0.59,1.285c0.086,0.232,0.13,0.467,0.13,0.696l-0.003,0.117
		C46.774,32.423,46.742,32.589,46.688,32.764z"></path><path d="M17.481,45.164c-0.586,0.275-1.183,0.53-1.774,0.759c-0.515,0.198-0.771,0.777-0.572,1.293
		c0.153,0.396,0.531,0.64,0.933,0.64c0.12,0,0.242-0.021,0.36-0.067c0.635-0.245,1.275-0.519,1.903-0.813
		c0.5-0.234,0.715-0.83,0.48-1.33C18.578,45.145,17.984,44.928,17.481,45.164z"></path><path d="M10.201,41.001c0.161,0,0.325-0.039,0.478-0.122c0.288-0.157,0.595-0.255,0.911-0.289c0.135-0.016,0.273-0.016,0.406,0.002
		c0.563,0.073,1.05-0.313,1.122-0.86c0.072-0.548-0.313-1.05-0.86-1.122c-0.298-0.039-0.601-0.041-0.891-0.008
		c-0.574,0.063-1.128,0.239-1.646,0.521c-0.485,0.265-0.664,0.871-0.399,1.356C9.504,40.813,9.847,41.001,10.201,41.001z"></path><path d="M9.993,48.842c0.216,0.056,0.436,0.098,0.654,0.124c0.256,0.031,0.512,0.047,0.769,0.047c0.313,0,0.627-0.022,0.94-0.062
		c0.548-0.069,0.937-0.569,0.867-1.117s-0.567-0.934-1.117-0.867c-0.404,0.052-0.812,0.064-1.216,0.015
		c-0.132-0.017-0.264-0.042-0.394-0.075c-0.535-0.143-1.08,0.181-1.22,0.716C9.139,48.158,9.459,48.704,9.993,48.842z"></path>
</g></svg></span>
                <h3 class="u-align-center u-text u-text-body-alt-color u-text-1">Paket 1</h3>
                <p class="u-align-center u-text u-text-body-alt-color u-text-2">Destinasi : Jogja<br>(2 hari 1 malam)<br>
                  <br>Prambanan, Malioboro, Jogja Bay,<br>Taman Pintar
                </p>
              </div>
            </div>
            <div class="u-container-style u-layout-cell u-palette-2-base u-size-20 u-layout-cell-2">
              <div class="u-container-layout u-valign-top u-container-layout-2"><span class="u-icon u-icon-circle u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 -101 713.75189 713"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-c3a6"></use></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -101 713.75189 713" id="svg-c3a6" class="u-svg-content"><path d="m85.085938 304.40625c-6.144532 2.882812-8.855469 10.140625-6.117188 16.34375l28.066406 60.25c1.378906 3 3.894532 5.335938 6.988282 6.488281 1.355468.492188 2.792968.746094 4.238281.746094 1.808593.015625 3.59375-.371094 5.238281-1.117187l212.054688-99.046876-19.207032 200.824219c-.371094 3.953125 1.152344 7.839844 4.109375 10.480469 9.296875 7.695312 20.882813 12.078125 32.9375 12.472656 3.324219-.003906 6.628907-.421875 9.851563-1.242187 17.214844-4.492188 30.5625-19.832031 39.667968-46.03125l83.449219-247.101563 165.273438-77.09375c48.648437-22.699218 73.71875-68.726562 56.882812-104.652344-9.554687-18.777343-27.855469-31.550781-48.773437-34.054687-23.242188-3.507813-46.996094.148437-68.105469 10.484375l-190.726563 89.433594-205.0625-80.207032c-25.824218-9.726562-46.277343-9.476562-60.621093.878907-12.035157 9.875-18.882813 24.71875-18.589844 40.285156.125 3.949219 2.113281 7.601563 5.363281 9.859375l138.082032 94.921875-79.078126 37.421875-132.601562-33.683594c-5.433594-1.335937-11.089844 1.113282-13.84375 5.988282l-33.050781 59.496093c-1.714844 3.152344-1.984375 6.894531-.738281 10.261719 1.238281 3.371094 3.871093 6.039062 7.226562 7.328125l98.167969 40.542969zm57.121093-248.09375c.734375-5.273438 3.402344-10.074219 7.488281-13.472656 7.113282-5.117188 20.085938-4.367188 37.421876 2.117187l182.617187 71.226563-83.328125 38.917968zm-112.257812 180.117188 21.703125-38.542969 127.605468 31.679687c2.75.695313 5.652344.433594 8.238282-.742187l414.75-193.71875c16.488281-8.132813 35.058594-11.09375 53.261718-8.484375 12.765626 1.175781 24.136719 8.542968 30.4375 19.707031 10.46875 22.457031-10.109374 55.261719-44.914062 71.476563l-143.695312 67.363281 8.734374-25.828125c2.207032-6.644532-1.398437-13.824219-8.042968-16.027344-6.652344-2.203125-13.828125 1.402344-16.03125 8.046875l-102.660156 305.476563c-6.113282 17.34375-13.722657 27.699218-22.203126 29.9375-5.253906 1.011718-10.691406-.019532-15.21875-2.863282l24.949219-261.953125c.652344-6.886719-4.398437-13-11.292969-13.652343-6.886718-.660157-13 4.398437-13.65625 11.285156l-3.863281 40.039062-214.054687 99.789063-17.578125-37.421875 35.167969-16.460938c4.527343-1.996094 7.445312-6.472656 7.445312-11.414062 0-4.945313-2.917969-9.421875-7.445312-11.414063zm0 0"></path></svg></span>
                <h3 class="u-align-center u-text u-text-body-alt-color u-text-3">Paket 2</h3>
                <p class="u-align-center u-text u-text-body-alt-color u-text-4">Destinasi : Bali<br>(4 hari 3 malam)<br>
                  <br>Kute, Tanah Lot, Nusa Dua, Bajra Sandi, Joger Jelek
                </p>
              </div>
            </div>
            <div class="u-align-center u-container-style u-layout-cell u-palette-3-base u-right-cell u-size-20 u-layout-cell-3">
              <div class="u-container-layout u-container-layout-3"><span class="u-icon u-icon-circle u-text-body-alt-color u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 354.053 354.053"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-b9b3"></use></svg><svg xmlns="http://www.w3.org/2000/svg" id="svg-b9b3" enable-background="new 0 0 354.053 354.053" viewBox="0 0 354.053 354.053" class="u-svg-content"><path d="m13.852 316.482 4.207 3.163c7.541 5.653 16.764 8.668 26.105 8.668 2.195 0 4.396-.201 6.585-.543 7.913 15.873 24.182 26.283 42.138 26.283h166.34c18.198 0 34.52-10.533 42.351-26.642.431.089.832.248 1.269.325 2.343.389 4.709.584 7.063.584 9.335 0 18.564-3.015 26.094-8.668l4.213-3.163c5.258-3.942 9.129-9.323 11.206-15.555 2.614-7.836 2.13-16.275-1.363-23.763l-36.88-79.036c-1.269-2.714-4.373-4.048-7.217-3.104l-12.321 4.107-11.418-93.635-.142.018c.035-6.644-1.157-13.336-3.617-19.738l-14.375-37.364c-4.349-11.312-15.419-18.912-27.539-18.912h-25.628c-2.82-16.72-17.359-29.507-34.873-29.507s-32.048 12.787-34.874 29.504h-25.628c-12.12 0-23.185 7.6-27.539 18.912l-14.369 37.365c-2.467 6.408-3.653 13.094-3.623 19.738l-.147-.018-11.341 93.01-10.439-3.482c-2.862-.944-5.942.389-7.217 3.104l-36.881 79.037c-3.493 7.488-3.977 15.926-1.363 23.763 2.089 6.231 5.966 11.607 11.223 15.549zm325.517-34.332c2.213 4.744 2.52 10.079.862 15.041-1.316 3.948-3.771 7.353-7.093 9.843l-4.213 3.163c-6.875 5.157-15.679 7.299-24.141 5.889-8.94-1.487-15.879-8.822-16.882-17.827l-9.087-81.745 25.893-8.627zm-86.289-229.502 14.369 37.364c5.122 13.312 3.228 28.183-5.063 39.79-6.491 9.093-16.422 15.177-27.321 17.059v-12.781c3.511-2.048 5.901-5.812 5.901-10.161v-11.802c0-4.349-2.39-8.114-5.901-10.161v-60.656h1.493c7.269 0 13.908 4.562 16.522 11.348zm-53.421 94.868h-47.207v-13.442c3.511-2.048 5.901-5.812 5.901-10.161v-11.802c0-4.349-2.39-8.114-5.901-10.161v-60.65h47.207v60.649c-3.511 2.048-5.901 5.812-5.901 10.161v11.802c0 4.349 2.39 8.114 5.901 10.161zm-76.711-23.598v-11.808h23.604v11.802zm17.702-23.609h-11.802v-59.009h11.802zm-11.801 35.405h11.802v44.764l-5.901 5.901-5.901-5.901zm76.711-11.796v-11.808h23.604v11.802zm17.703-23.609h-11.802v-59.009h11.802zm-11.802 35.405h11.802v44.764l-5.901 5.901-5.901-5.901zm-35.405-123.918c10.964 0 20.128 7.553 22.766 17.703h-45.532c2.638-10.15 11.802-17.703 22.766-17.703zm-91.393 78.21 14.369-37.364c2.614-6.786 9.253-11.347 16.522-11.347h1.493v60.649c-3.511 2.048-5.901 5.812-5.901 10.161v11.802c0 4.349 2.39 8.114 5.901 10.161v12.781c-10.899-1.882-20.83-7.966-27.321-17.065-8.291-11.589-10.185-26.466-5.063-39.778zm-6.338 43.773c.602.962 1.133 1.947 1.794 2.874 8.698 12.179 22.211 20.187 36.928 22.164v24.105c0 1.564.62 3.068 1.729 4.172l11.802 11.802c1.151 1.151 2.661 1.729 4.172 1.729s3.021-.578 4.172-1.729l11.802-11.802c1.109-1.109 1.729-2.608 1.729-4.172v-23.604h47.207v23.604c0 1.564.62 3.068 1.729 4.172l11.802 11.802c1.151 1.151 2.661 1.729 4.172 1.729s3.021-.578 4.172-1.729l11.802-11.802c1.109-1.109 1.729-2.608 1.729-4.172v-24.105c14.711-1.971 28.23-9.978 36.922-22.158.667-.932 1.198-1.918 1.8-2.88l8.438 69.164-11.66 3.889c-2.638.879-4.302 3.481-3.995 6.249l9.613 86.483c1.08 9.754 6.633 18.181 14.534 23.326-5.989 11.737-18.068 19.355-31.487 19.355h-166.342c-12.976 0-24.843-7.217-30.997-18.399 8.698-5.01 14.858-13.92 16.009-24.282l9.607-86.483c.307-2.767-1.357-5.37-3.995-6.249l-13.543-4.514zm-63.623 148.371 34.662-74.268 25.893 8.627-9.081 81.745c-1.003 9.005-7.943 16.34-16.877 17.827-8.491 1.404-17.278-.738-24.146-5.889l-4.207-3.163c-3.328-2.49-5.783-5.901-7.099-9.843-1.665-4.951-1.358-10.291.855-15.036z"></path><path d="m140.65 330.443h70.811c13.017 0 23.604-10.586 23.604-23.604v-47.207l7.081 9.441 9.441-7.081-16.522-22.028v-3.936c0-13.017-10.586-23.604-23.604-23.604h-70.811c-13.017 0-23.604 10.586-23.604 23.604v70.811c.001 13.018 10.587 23.604 23.604 23.604zm-11.801-94.414c0-6.509 5.293-11.802 11.802-11.802h70.811c6.509 0 11.802 5.293 11.802 11.802v70.811c0 6.509-5.293 11.802-11.802 11.802h-70.812c-6.509 0-11.802-5.293-11.802-11.802v-70.811z"></path><path d="m140.65 241.93h70.811v11.802h-70.811z"></path></svg></span>
                <h3 class="u-text u-text-body-alt-color u-text-5">Paket 3</h3>
                <p class="u-text u-text-body-alt-color u-text-6">Destinasi : Raja Ampat<br>(6 hari 6 malam)<br>
                  <br>Misool, Star Lagoon, Batu Pensil, Wayag, Desa Arborek, Pasir Timbul
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <h2 class="u-heading-font u-subtitle u-text u-text-body-alt-color u-text-default u-text-7">Yuk, main bareng dengan kami</h2>
    </section>
    
    
    <footer class="u-clearfix u-footer u-grey-80" id="sec-c996"><div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-left u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1">
                <div class="u-container-layout u-valign-top u-container-layout-1"><!--position-->
                  <div data-position="" class="u-position u-position-1"><!--block-->
                    <div class="u-block">
                      <div class="u-block-container u-clearfix"><!--block_header-->
                        <h5 class="u-block-header u-text u-text-1"><!--block_header_content-->Alamat<!--/block_header_content--></h5><!--/block_header--><!--block_content-->
                        <div class="u-block-content u-text u-text-2"><!--block_content_content-->Jl. Sukamaju No.76, Jebres, Surakarta<br>573663<br>Jawa Tengah, Indonesia<!--/block_content_content-->
                        </div><!--/block_content-->
                      </div>
                    </div><!--/block-->
                  </div><!--/position-->
                </div>
              </div>
              <div class="u-align-left u-container-style u-layout-cell u-right-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-valign-top u-container-layout-2"><!--position-->
                  <div data-position="" class="u-position u-position-2"><!--block-->
                    <div class="u-block">
                      <div class="u-block-container u-clearfix"><!--block_header-->
                        <h5 class="u-block-header u-text u-text-3"><!--block_header_content--> Kontak Kami<!--/block_header_content--></h5><!--/block_header--><!--block_content-->
                        <div class="u-block-content u-text u-text-4"><!--block_content_content--> (0271) 8876 887 - Telepon<br>(62) 8866 3513 2211 - Whatsapp<!--/block_content_content-->
                        </div><!--/block_content-->
                      </div>
                    </div><!--/block-->
                  </div><!--/position-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a>
        Copyright &copy; <script>document.write(new Date().getFullYear())</script> -</p>
      </a>
      <a class="u-link" href="index.php" target="_blank">
        Ayodolan[dot]com
      </a>
      <br>
      All Rights Reserved
    </section>
  </body>
</html>