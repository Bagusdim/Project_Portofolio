<?php
    $servername = "";
    $username   = "root";
    $password   = "";
    $db         = "agenwisata";
    $conn       = new mysqli($servername, $username, $password, $db);
?>